import sys, subprocess
import os
import networkx as nx
import numpy as np
import networkx.algorithms.isomorphism as iso
from datetime import datetime

qfile=input("please enter query file name:")
qdata=open(qfile,"r")
inputs=open("thisismyinput","r")
wr=open("output_MCS212142.txt","w+");
gfeatures=open("features.txt","r");
pattern=open("pattern.txt","r")


print("Query file loaded")
print("Qeury processing started");


cnt=0

date=datetime.utcnow()

while True:
	pattern.seek(0,0)
	gfeatures.seek(0,0)
	inputs.seek(0,0)
	line=qdata.readline()
	if not line:
		break
	if line=="\n" or len(line)==0:
		continue;
	g=nx.Graph()
	if(line[0]=='#'):
		cnt=cnt+1
		line=qdata.readline()
	nodes=int(line)
	nodes=nodes-1
	start=0;
	while True:
		while (start<=nodes):	
			line=qdata.readline()
			g.add_node(start,attr=line.strip());
			start=start+1
		line=qdata.readline()
		edges=int(line.strip())
		starte=0 
		while (starte<edges):
			line=qdata.readline()
			line=line.strip().split()
			g.add_edge(int(line[0]),int(line[1]),attr=line[2]);
			starte=starte+1
		break
	features=[]
	op=0

	while True:
		g1=nx.Graph();
		line1=pattern.readline()
		if not line1:
			break
		if line1=="\n":
			continue;
		if(line1[0]=='#'):
			line1=pattern.readline()
		nodes=int(line1)
		nodes=nodes-1
		start=0;
		while (start<=nodes):	
			line1=pattern.readline()
			g1.add_node(start,attr=line1.strip());
			start=start+1
		line1=pattern.readline()
		edges=int(line1)
		starte=0
		while (starte<edges):
			line1=pattern.readline()
			line1=line1.strip().split()
			g1.add_edge(int(line1[0]),int(line1[1]),attr=line1[2]);
			starte=starte+1

		GM=iso.GraphMatcher(g,g1,node_match=iso.categorical_node_match('attr','attr'),edge_match=iso.categorical_node_match('attr','attr'))
		features.append(GM.subgraph_is_isomorphic())

	plen=len(features)
	gline=gfeatures.readline();
	ids=[]
	op=-1;
	while True:
		iline=inputs.readline()
		gid=""
		if not iline:
			break;
		if iline=="\n":
			continue;
		if iline[0]=="#":
			gid=iline[1:]
			op=op+1
			print("Query",cnt," Graph",op)
			iline=inputs.readline()
		igraph=nx.Graph()
		inodes=int(iline)
		inodes=inodes-1
		start=0;
		while True:
			while (start<=inodes):	
				iline=inputs.readline()
				igraph.add_node(start,attr=iline.strip());
				start=start+1
			iline=inputs.readline()
			iedges=int(iline.strip())
			starte=0
			while (starte<iedges):
				iline=inputs.readline()
				iline=iline.strip().split()
				igraph.add_edge(int(iline[0]),int(iline[1]),attr=iline[2]);
				starte=starte+1
			break
		GM=iso.GraphMatcher(igraph,g,node_match=iso.categorical_node_match('attr','attr'),edge_match=iso.categorical_node_match('attr','attr'))
		match=True
		if op==int(gline.strip().split()[0]):
			gline=gline.strip().split();
			for i in range(1,plen+1):
				if gline[i]=='0' and features[i-1]=='1':
					match=False
					break;		
			gline=gfeatures.readline();
		if match:
			isS=GM.subgraph_is_isomorphic()
			if isS:
				gid=gid.strip()
				ids.append(gid)

	lo=len(ids)
	for i in range(0,lo-1):
		wr.write(ids[i])
		wr.write("\t");
	if(lo>=1):
		wr.write(ids[lo-1])
	wr.write("\n")
	wr.flush()

date=datetime.utcnow()-date;
print("Time taken in seconds:",date.total_seconds())
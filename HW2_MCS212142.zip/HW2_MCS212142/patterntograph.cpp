#include<bits/stdc++.h>
#include<iostream>
#include<fstream>
#include<cstring>
#include<map>
#include<unordered_map>
using namespace std;

fstream ifile,ofile,lfile;
int cnt=0;

vector<string> labels;
vector<string> edges;
map<int,string> labelmap;

int main(int a,char *args[])
{

string infile=args[1];
string otfile=args[2];
ifile.open(infile,ios::in);
lfile.open("labelid_mapping",ios::in);
ofile.open(otfile,ios::out);


string maps;

while(getline(lfile,maps))
{
stringstream line1(maps);
string query;
string mylabel;
int val;
bool done=false;

while(getline(line1,query,' '))
{
        if(done==true){
val=stoi(query);
        }
else{done=true;
mylabel=query;}
}
labelmap[val]=mylabel;
}


string counting;
string line;
while(getline(ifile,line))
{
 if(line[0]=='t')
 {
         ++cnt;
 }
}

ifile.clear();
ifile.seekg(0);
int toskip=cnt-15;

if(toskip<0){
        toskip=0;
}

int t=0;

while(getline(ifile,line))
{
 if(line.length()==0 || line=="\n" || line=="")
 {
         continue;
 }

 if(line[0]=='t')
{
if(t!=(toskip+1))
{
        ++t;
}
}
else if(t!=(toskip+1)){
        continue;
}


stringstream line1(line);
string query;
vector<string> myline;
bool add=false;
while(getline(line1,query,' '))
{
if(query=="x")
{
	add=true; 
        break;
}
myline.push_back(query);
}


if(add==true)
{
ofile<<"#pattern"<<endl;
ofile<<labels.size()<<endl;
for(int i=0;i<labels.size();i++)
{ofile<<labelmap[stoi(labels[i])]<<endl;}
ofile<<edges.size()<<endl;
for(int i=0;i<edges.size();i++)
{ofile<<edges[i]<<endl;}
labels.clear();
edges.clear();
continue;
}

if(myline[0]=="v"){
labels.push_back(myline[2]);
}
else if(myline[0]=="e"){
string temp=myline[1]+" "+myline[2]+" "+myline[3];
edges.push_back(temp);
}
else{	continue;}
}


return 0;
}
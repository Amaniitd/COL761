ifile=$1;
echo "Finding frequent Subgraphs..."
cp $ifile thisismyinput
g++ md.cpp -o md.o -std=c++11
./md.o thisismyinput
chmod u+x gSpan
./gSpan -f formattogspan -s 0.95 -o -i
echo "Building Index...."
g++ generate_index.cpp -o gi.o -std=c++11
./gi.o
g++ patterntograph.cpp -o ptg.o -std=c++11
./ptg.o formattogspan.fp pattern.txt
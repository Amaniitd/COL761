Submitted Files:

Part 1:

Explanations.txt: Contains the explanation about the trends observed in plots about these algorithms.
fsg: FSG binary file
gaston: Gaston binary file
gSpan-64: gSpan binary file
Q1.py: Contains the code for Q1, takes input file name as commandline argument
Q1.sh: Bash file to run Q1, pass yeast database as input for Q1.py
Q1.png: Output plot for performance of three algorithms


Part 2:

generate_index.cpp: Generate index of graphs containing subgraph patterns
patterntograph.cpp: Convert frequent subgraphs outputfile to format similar to input format
index.sh: bash file for creating index
gSpan: GSPAN algorithm executable
md: Converts input data to suitable format for input in gSpan executable
query.sh: Bash file to run queries. Executes query.py
query.py: Ask for query file and run the queries

Part 3:

elbow_plot.sh:Bash file to provide arguemnts to kemans algorithm
kmeans.py: Kmeans implementation code

==========================================================================
Team Members
1. Sohail Khan - 2021MCS2153
2. Aman Kumar - 2019CS10324
3. Nitin Kumar - 2021MCS2142
==========================================================================

HOW TO RUN?

Part 1:

a) Run Q1.sh, it will run algorithms on Yeast dataset
b) Run Q1.py <inputfilename> to run algorithms for input dataset

Part 2:
1. Run index.sh as->sh index.sh <inputfilename>
2. Then run sh query.sh, 
3. Enter the name of query file

Part 3:
1. Run sh elbow_plot.sh <dataset> <dimension> q3_<dimension>_<RollNo>.png

==========================================================================
Contribution of Each Student
Everyone contributed equally in each part. 
1. Sohail Khan - 33%
2. Aman Kumar - 33%
3. Nitin Kumar - 33%
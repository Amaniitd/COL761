#!/bin/sh
module load apps/anaconda/3
chmod u+x fsg
chmod u+x gaston
chmod u+x gSpan-64
python3 Q1.py 167.txt_graph
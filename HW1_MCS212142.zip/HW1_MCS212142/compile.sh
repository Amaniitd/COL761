g++ -O3 fptree.cpp -o fptree.o
g++ -O3 apriori.cpp -o apriori.o
g++ -O3 do_plot.cpp -o run.o